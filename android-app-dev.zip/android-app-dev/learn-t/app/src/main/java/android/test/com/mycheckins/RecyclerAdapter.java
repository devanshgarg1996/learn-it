package android.test.com.mycheckins;


import android.content.Context;
import android.content.Intent;
//import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView;
import android.test.com.mycheckins.model.Checkin;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private List<Checkin> responses;

    Context ctx;

    public RecyclerAdapter(Context context, List<Checkin> responses) {
        ctx = context;
        this.responses = responses;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final Checkin checkin = responses.get(position);


        holder.title.setText(checkin.getTitle());
        holder.date.setText(checkin.getDate());
        holder.dest.setText(checkin.getDestination());


        holder.main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent i = new Intent(ctx, RecordActivity.class);
                i.putExtra("key", "FROM_LIST");
                i.putExtra("keyId", checkin.getId());

                ctx.startActivity(i);


            }
        });

    }

    @Override
    public int getItemCount() {
        return responses.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        protected TextView title, date, dest;

        RelativeLayout main;


        public MyViewHolder(View itemView) {
            super(itemView);


            title = itemView.findViewById(R.id.title);

            date = itemView.findViewById(R.id.date);
            dest = itemView.findViewById(R.id.destination);


            main = itemView.findViewById(R.id.main);


        }
    }
}
