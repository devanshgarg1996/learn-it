package android.test.com.mycheckins;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.test.com.mycheckins.model.Checkin;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    //  Version
    private static final int DATABASE_VERSION = 1;
    //  Name
    private static final String DATABASE_NAME = "checkins_db";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Checkin.CREATE_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Checkin.TABLE_NAME);
        onCreate(db);
    }


    public long insertCheckin(Checkin checkin) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Checkin.COLUMN_TITLE, checkin.getTitle());
        values.put(Checkin.COLUMN_DATE, checkin.getDate());
        values.put(Checkin.COLUMN_PHOTO, checkin.getPhoto());
        values.put(Checkin.COLUMN_DEST, checkin.getDestination());
        values.put(Checkin.COLUMN_LOCATION, checkin.getLocation());

        // insert row
        long id = db.insert(Checkin.TABLE_NAME, null, values);

        db.close();

        return id;
    }


    public Checkin getRecord(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Checkin.TABLE_NAME, new String[]{Checkin.COLUMN_ID, Checkin.COLUMN_TYPE, Checkin.COLUMN_TITLE, Checkin.COLUMN_DURATION, Checkin.COLUMN_DATE, Checkin.COLUMN_DEST, Checkin.COLUMN_COMMENT, Checkin.COLUMN_PHOTO, Checkin.COLUMN_LOCATION

        }, Checkin.COLUMN_ID + "=?", new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null) cursor.moveToFirst();

        // prepare  object
        Checkin checkin = new Checkin(
                cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_TITLE)),
                cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_DATE)),
                cursor.getBlob(cursor.getColumnIndex(Checkin.COLUMN_PHOTO)),
                cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_DEST)),
                cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_LOCATION)),
                cursor.getInt(cursor.getColumnIndex(Checkin.COLUMN_ID)));

//        cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_COMMENT)),

        cursor.close();

        return checkin;
    }


    public List<Checkin> getAllRecords() {
        List<Checkin> checkins = new ArrayList<>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + Checkin.TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Checkin checkin = new Checkin();
                checkin.setId(cursor.getInt(cursor.getColumnIndex(Checkin.COLUMN_ID)));
                checkin.setTitle(cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_TITLE)));
                checkin.setDate(cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_DATE)));
                checkin.setPhoto(cursor.getBlob(cursor.getColumnIndex(Checkin.COLUMN_PHOTO)));
                checkin.setDestination(cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_DEST)));
                checkin.setLocation(cursor.getString(cursor.getColumnIndex(Checkin.COLUMN_LOCATION)));
                checkins.add(checkin);
            } while (cursor.moveToNext());
        }
        db.close();
        return checkins;
    }


    public void deleteRecord(Checkin checkin) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Checkin.TABLE_NAME, Checkin.COLUMN_ID + " = ?", new String[]{String.valueOf(checkin.getId())});
        db.close();
    }

}
