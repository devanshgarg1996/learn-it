package android.test.com.mycheckins;

import android.content.Intent;
import android.os.Bundle;

public class RecordActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_record);
        String data;

        int keyId;

        Intent intent = getIntent();

        if (getIntent().hasExtra("key")) {
            data = getIntent().getStringExtra("key");
            if (data.equalsIgnoreCase("LOG")) {
                // if log btn clicked
                showCreateRecordScreen();
            }
        }

        if (getIntent().hasExtra("key")) {
            data = getIntent().getStringExtra("key");

            keyId = getIntent().getIntExtra("keyId", 1);


            if (data.equalsIgnoreCase("FROM_LIST")) {

                // if log btn clicked
                showCreateRecordScreen(getIntent().getIntExtra("keyId", keyId));
            }
        }

    }

    @Override
    protected void setUp() {
    }

    private void showCreateRecordScreen(int id) {
        Bundle args = new Bundle();
        CreateRecordFragment createRecordFragment;
        createRecordFragment = CreateRecordFragment.newInstance(id);
        createRecordFragment.setArguments(args);
        attachFragment(createRecordFragment, CreateRecordFragment.FRAGMENT_TAG);

    }


    private void showCreateRecordScreen() {
        Bundle args = new Bundle();
        args.putString("key ", "value");
        CreateRecordFragment createRecordFragment;
        createRecordFragment = CreateRecordFragment.newInstance();
        createRecordFragment.setArguments(args);
        attachFragment(createRecordFragment, CreateRecordFragment.FRAGMENT_TAG);

    }

}