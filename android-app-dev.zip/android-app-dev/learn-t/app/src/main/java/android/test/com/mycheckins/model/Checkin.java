package android.test.com.mycheckins.model;

import java.util.Arrays;

public class Checkin {

    public static final String TABLE_NAME = "checkins";

    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_DURATION = "duration";
    public static final String COLUMN_COMMENT = "comment";
    public static final String COLUMN_PHOTO = "photo";
    public static final String COLUMN_DEST = "destination";
    public static final String COLUMN_LOCATION = "location";

    public static final String COLUMN_ID = "id";


    private String title;
    private String date;

    private String destination;

    private String location;
    private  byte[] photo;


    private int id;



    public static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_TITLE + " TEXT,"  + COLUMN_DATE + " TEXT," + COLUMN_DURATION + " TEXT," +
            COLUMN_COMMENT + " TEXT," + COLUMN_PHOTO + " BLOB," + COLUMN_DEST + " TEXT," + COLUMN_LOCATION + " TEXT," + COLUMN_TYPE + " TEXT" + ")";


    public Checkin() {
    }


    public Checkin(String title, String date,



                   byte[] photo, String destination, String location) {
        this.title = title;
        this.date = date;

        this.photo = photo;
        this.destination = destination;
        this.location = location;
    }



    public Checkin(String title, String date,


                   byte[] photo, String destination, String location, int id) {
        this.title = title;
        this.date = date;
        this.photo = photo;
        this.destination = destination;
        this.location = location;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public  byte[] getPhoto() {
        return photo;
    }

    public void setPhoto( byte[] photo) {
        this.photo = photo;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Checkin{" +
                "title='" + title + '\'' +
                ", date='" + date + '\'' +
                ", destination='" + destination + '\'' +

                ", location='" + location + '\'' +
                ", photo=" + Arrays.toString(photo) +
                ", id=" + id +
                '}';
    }
}
